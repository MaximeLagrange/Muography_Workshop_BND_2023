#include "DetectorConstruction.hh"
#include "MySensitiveDetector.hh"

#include <vector>
#include <sstream>

#include "G4HCofThisEvent.hh"
#include "G4TouchableHistory.hh"
#include "G4Step.hh"
#include "G4SDManager.hh"
#include "G4ios.hh"
#include "G4DynamicParticle.hh"
#include "G4VProcess.hh"
#include "G4MuMultipleScattering.hh"
#include "G4ParticleDefinition.hh"


MySensitiveDetector::MySensitiveDetector(const G4String &SDname) : 
G4VSensitiveDetector(SDname),fHitsCollection(0), fHCID(-1)
{
    collectionName.insert("SensitiveDetectorColl");
}
MySensitiveDetector::~MySensitiveDetector()
{}

void MySensitiveDetector::Initialize( G4HCofThisEvent *hitcollection )
{
  fHitsCollection = new PannelHitsCollection(SensitiveDetectorName, collectionName[0]);
  if ( fHCID < 0 ) {
    fHCID = G4SDManager::GetSDMpointer()->GetCollectionID(fHitsCollection);
  }
  hitcollection->AddHitsCollection( fHCID, fHitsCollection);
  G4cout << "Initialize PannelSD hitcoll ID: " << fHCID << G4endl; 

}

G4bool MySensitiveDetector::ProcessHits(G4Step *aStep, G4TouchableHistory *R0hist)
{
//Define physics variables 
    G4double edep = aStep->GetTotalEnergyDeposit();



  
 
//Define hit

    auto hit = new PannelHit();
    
//Set variables position and pannelId
    hit->SetEdep(edep);


//Print    
    hit->Print();
//insert Hit to collection
    fHitsCollection->insert(hit);


    return true;
}

void MySensitiveDetector::EndOfEvent( G4HCofThisEvent *hitCollection ) {}
