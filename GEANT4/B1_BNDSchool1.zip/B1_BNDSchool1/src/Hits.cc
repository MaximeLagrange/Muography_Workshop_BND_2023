#include "Hits.hh"
#include "DetectorConstruction.hh"
#include "G4AttDefStore.hh"
#include "G4AttDef.hh"
#include "G4AttValue.hh"
#include "G4UIcommand.hh"
#include "G4UnitsTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4ios.hh"

G4ThreadLocal G4Allocator<PannelHit>* PannelHitAllocator;

PannelHit::PannelHit()
  : G4VHit()
{}

PannelHit::~PannelHit()
{}

void PannelHit::Draw()
{}

void PannelHit::Print()
{}

const std::map<G4String,G4AttDef>* PannelHit::GetAttDefs() const
{
  G4bool isNew;
  auto store = G4AttDefStore::GetInstance("PannelHit", isNew);

  if ( isNew ) {   
    (*store)["HitType"] = G4AttDef("HitType", "Hit Type", "Physics", "", "G4String" );
    //(*store)["Pannel"] = G4AttDef("Pannel", "Pannel ID", "Physics", "", "G4int" );
    (*store)["Energy"] = G4AttDef("Energy", "Energy deposit", "Physics", "G4BestUnit", "G4double" );
    (*store)["Pos"] = G4AttDef("Pos", "Position", "Physics", "G4BestUnit", "G4ThreeVector" );
    (*store)["PDG"] = G4AttDef("PDG", " PDG", "", "G4BestUnit", "G4double" );                                      
  }  
  return store;
}

std::vector<G4AttValue>* PannelHit::CreateAttValues() const
{
  auto values = new std::vector<G4AttValue>;
  
  values->push_back( G4AttValue( "HitType", "PannelHit", "" ));
 // values->push_back( G4AttValue( "Pannel", G4UIcommand::ConvertToString(fPannelID),""));
  values->push_back( G4AttValue( "Energy", G4BestUnit(fEdep,"Energy"),""));
  values->push_back( G4AttValue( "Pos", G4BestUnit(fPos,"Length"),""));
  values->push_back( G4AttValue( "PDG", G4UIcommand::ConvertToString(fPDG),""));     
  return values;
}




