//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file DetectorConstruction.cc
/// \brief Implementation of the B1::DetectorConstruction class

#include "DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4VisAttributes.hh"
#include "G4RotationMatrix.hh"
#include "G4Material.hh"


//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::DetectorConstruction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction::~DetectorConstruction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();

  // Envelope parameters
  //



  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  //
  // World
  //
  G4double env_sizeXY = 20*m, env_sizeZ = 20*m; 
  G4double world_sizeXY = 1.2*env_sizeXY;
  G4double world_sizeZ  = 1.2*env_sizeZ;
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");

  G4Box* solidWorld =
    new G4Box("World",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size

  G4LogicalVolume* logicWorld =
    new G4LogicalVolume(solidWorld,          //its solid
                        world_mat,           //its material
                        "World");            //its name

  G4VPhysicalVolume* physWorld =
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking

  //rotation
   
   G4double rotAngle = 180.;
   G4RotationMatrix * _rot= new G4RotationMatrix();
    _rot->rotateY(rotAngle * deg); 
  
  //
  // Mother Volume
  //
  G4Material* mother_mat = nist->FindOrBuildMaterial("G4_Galactic");  
  G4Box* solidMother =
    new G4Box("MotherB",                    //its name
        0.5*env_sizeXY, 0.5*env_sizeXY, 0.5*env_sizeZ); //its size

  G4LogicalVolume* logicMother =
    new G4LogicalVolume(solidMother,            //its solid
                        mother_mat,             //its material
                        "MotherL");         //its name

  new G4PVPlacement(0,                       //no rotation
                    G4ThreeVector(0,0,-1*cm),         //at (0,0,0)
                    logicMother,                //its logical volume
                    "MotherS",              //its name
                    logicWorld,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking

  //In case you need to create your own mixture of material that didn't exist in G4 try that :
  
  /*
      G4String name, symbol;                           
      G4double a, z;  
      G4double density, fractionmass; 
      G4int nel, ncomponents;
   
     // define Elements
     
      a = 1.01*g/mole;
     G4Element* elH  = new G4Element(name="Hydrogen",symbol="H" , z= 1., a);
   
   
      a = 12.01*g/mole;
     G4Element* elC = new G4Element(name="Carbon", symbol="C", z=6., a);
  
  
       a = 15.999*g/mole;
     G4Element* elO = new G4Element(name="Oxygen", symbol="O", z=8., a);

  
     a = 40.078*g/mole;
     G4Element* elCa = new G4Element(name="Calcium", symbol="Ca", z=20., a);
  
     a = 24.305*g/mole;
     G4Element* elMg = new G4Element(name="Magnesium", symbol="Mg", z=12., a);
  
  
  

  
    density = 2.71*g/cm3;
    G4Material* comp1 = new G4Material(name="comp1",density,nel=3);
    comp1->AddElement(elC,1);
    comp1->AddElement(elCa,1);
    comp1->AddElement(elO,3);   
    
    density = 2.96*g/cm3;
    G4Material* comp2 = new G4Material(name="comp2",density,nel=3);
    comp2->AddElement(elC,1);
    comp2->AddElement(elMg,1);
    comp2->AddElement(elO,3);   
    
    density = 2.65*g/cm3;    
    G4Material* rock = new G4Material(name="rock"  , density, nel=4);     
    rock->AddElement( elO,              fractionmass = 0.52);
    rock->AddElement( elC,   fractionmass = 0.12);
    rock->AddElement( elMg,   fractionmass = 0.09);
    rock->AddElement( elCa,   fractionmass = 0.27);


*/

  //Plastic
  G4Material* detector_mat = nist->FindOrBuildMaterial("G4_PLASTIC_SC_VINYLTOLUENE");

  // Conical section shape
 /* G4double shape1_rmina =  0.*cm, shape1_rmaxa = 2.*cm;
  G4double shape1_rminb =  0.*cm, shape1_rmaxb = 4.*cm;
  G4double shape1_hz = 3.*cm;
  G4double shape1_phimin = 0.*deg, shape1_phimax = 360.*deg;
  G4Cons* solidShape1 =
    new G4Cons("Shape1",
    shape1_rmina, shape1_rmaxa, shape1_rminb, shape1_rmaxb, shape1_hz,
    shape1_phimin, shape1_phimax);
  */
  

     //Position of my planes => an array 

    G4double zPosSc0 = 0*cm; 
    G4double zPosSc1 = zPosSc0 - 20*cm;     
    G4double zPosSc2 = zPosSc0 - 40*cm; 
    G4double zPosSc3 = zPosSc0 - 80*cm; 
    G4double zPosSc4 = zPosSc0 - 100*cm;         
    G4double zPosSc5 = zPosSc0 - 120*cm;      

    G4double zPosSc[] = {zPosSc0, zPosSc1,zPosSc2, zPosSc3, zPosSc4, zPosSc5};
 
 
 
  G4Box *solidDetector = new G4Box("solidDetector", 0.5*m, 0.5*m, 0.01*m);

  

  G4LogicalVolume* logicDetector = new G4LogicalVolume(solidDetector, 
              detector_mat, 
              "logicDetector"); 

  //Copy number
   G4int CopyNo=0;
   std::stringstream PannelName;  
 for (G4int iSc=0;iSc<6;iSc++)

{
//give the CopyNo like an identity for each plane
   CopyNo = iSc ; //=> 0 1 2 3 4 5 for planes 
    PannelName << iSc;                                                    
    new G4PVPlacement(0,                   //no rotation
                      G4ThreeVector(0,0,zPosSc[iSc]),  //its position
                      logicDetector,     //its logical volume
                      "Pannel" + PannelName.str(), //its name
                       logicMother,          //its mother
                       false,               //no boulean operat
                       CopyNo);                   //copy number
                                        
}
  
  

 //Dependant on the application we choose the position , this position->Scattering application
 
  G4Material* lead_mat = nist->FindOrBuildMaterial("G4_Pb"); 
   G4Box* solidLead =
    new G4Box("SolidLead",                    //its name
        10*cm, 10*cm, 10*cm); //its size

  G4LogicalVolume* logicLead =
    new G4LogicalVolume(solidLead,            //its solid
                        lead_mat,             //its material
                        "LogicLead");         //its name

  new G4PVPlacement(0,                       //no rotation
                    G4ThreeVector(0,0,-60*cm),         //at (0,0,0)
                    logicLead,                //its logical volume
                    "MotherS",              //its name
                    logicMother,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking
 

   fScoringVolume= logicDetector; 
//For hidden material =>Substracion from the mesh and place your object : use G4Substraction   
  
  logicMother->SetVisAttributes(G4VisAttributes::GetInvisible());
  logicWorld->SetVisAttributes(G4VisAttributes::GetInvisible()); 
  
  G4VisAttributes* cyancol = new G4VisAttributes(G4Colour(0.,1.,1.,0.3));  
  fScoringVolume->SetVisAttributes(cyancol); 
  //always return the physical World
  //
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//Add ConstructSDandField



