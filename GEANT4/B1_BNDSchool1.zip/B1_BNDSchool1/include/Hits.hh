//

#ifndef Hits_h
#define Hits_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class G4AttDef;
class G4AttValue;

class PannelHit : public G4VHit
{
public:
  PannelHit();
  virtual ~PannelHit();
  
  inline void *operator new(size_t);
  inline void operator delete(void *aHit);

  virtual void Draw();
  virtual void Print();

  virtual const std::map<G4String,G4AttDef>* GetAttDefs() const;
  virtual std::vector<G4AttValue>* CreateAttValues() const;
  
 //Set and Get methods 

  void SetPos( G4ThreeVector xyz ) { fPos = xyz; };
  G4ThreeVector GetPos() const { return fPos; };
  
  void SetEdep( G4double de ) { fEdep = de; };
  void AddEdep( G4double de) { fEdep += de; };
  G4double GetEdep() const { return fEdep; }

  
  void SetPDG( G4double id ) { fPDG = id; };
  G4double GetPDG() const { return fPDG; };

//Variables

private:

  G4double fEdep;
  G4double fPDG;
  G4ThreeVector fPos;

};

typedef G4THitsCollection<PannelHit> PannelHitsCollection;

extern G4ThreadLocal G4Allocator<PannelHit>* PannelHitAllocator;

inline void* PannelHit::operator new(size_t)
{
  if (!PannelHitAllocator) {
       PannelHitAllocator = new G4Allocator<PannelHit>;
  }
  return (void*)PannelHitAllocator->MallocSingle();
}

inline void PannelHit::operator delete(void* aHit)
{
  PannelHitAllocator->FreeSingle((PannelHit*) aHit);
}


#endif
