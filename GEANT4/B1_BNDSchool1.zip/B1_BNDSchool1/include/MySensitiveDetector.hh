#ifndef MySensitiveDetector_HH 
#define MySensitiveDetector_HH

#include "G4VSensitiveDetector.hh"
#include "Hits.hh"

class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;

class MySensitiveDetector : public G4VSensitiveDetector
{
public:
    MySensitiveDetector(const G4String &SDname);
    ~MySensitiveDetector();


  virtual void Initialize( G4HCofThisEvent *hitcollection );
  virtual G4bool ProcessHits( G4Step *step, G4TouchableHistory *history );
  virtual void EndOfEvent( G4HCofThisEvent* hitCollection );
  
private:
  PannelHitsCollection* fHitsCollection;
  G4int fHCID;

};


#endif

